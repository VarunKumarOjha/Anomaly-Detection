/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package anomalydetection;

import java.util.Scanner;
import java.io.*;

/**
 *
 * @author Varun
 */
public class AnomalyDetection {

    //private int row, ;  //Rows and Column for training matrix
    //private int crow, ccol;//Rows and Column for crossvalidiation matrix
    //private int trow, tcol;//Rows and Column for test matrix 
    private double[][] mat; //training set
    private double[][] matc;//cross validiation set
    private double[][] matt;//test set
    private int[] yval;//traget (type) of coresponting crossvalidiation set
    private int[] ytest;//traget (type) of coresponting test set
    private double m[][];//holds cofactors of determinants
    private final String filePath = System.getProperty("user.dir") + File.separator + "data" + File.separator;

    public void start() {

        //Read data and define matrices
        readData();

        //computint the parameters fro Gussian ditibution
        double[] mu = mean(mat);// finding mu for training set features
        //for(i=0;i<col;i++){System.out.println(" mu : "+mu[i]);}//printing mu

        double[] var = sigma2(mat, mu);// finding sigma2 for training set features
        //for(i=0;i<col;i++){System.out.println(" Var: "+var[i]);}//printing varience

        //double[] p = multivarate_gaussian(mat, mu, var);
        
        double[] pval = multivarate_gaussian(matc, mu, var);
        //for(i=0;i<crow;i++){System.out.println(" "+p[i]);}//printing pval
        //for(i=0;i<crow;i++){System.out.println(" "+yc[i]);}//printing yval

        //System.out.println("The epcilon calculation begins"); 
        double epsilon = select_threshold(yval, pval);//finding epsilon
        System.out.println("The epcilon is: " + epsilon);
        
        //find outlier
        //test data code
    }


    /*Mean Calculation*/
    public double[] mean(double matm[][]) {
        int mu_row = matm.length;
        int mu_col = matm[0].length;
        System.out.println("Computing mean of variables of matrix: "+ mu_row +" x "+mu_col);
        double mu[] = new double[mu_col];
        double temp[] = new double[mu_col];

        for (int j = 0; j < mu_col; j++) {
            temp[j] = 0.0;
        }//initilization of temp to zero
        for (int j = 0; j < mu_col; j++) {//j columns
            for (int i = 0; i < mu_row; i++) {//i rows
                //System.out.print(" "+mat[j][i]);  
                temp[j] = temp[j] + matm[i][j];
            }
            temp[j] = temp[j] / ((double) mu_row);
            //System.out.println(" >mu"+i+": "+temp[i]); 
        }
        //copy temp to mu
        System.arraycopy(temp, 0, mu, 0, mu_col); //System.out.println(" "+mu[i]);

        return mu;
    }


    /*Varience Calculation*/
    public double[] sigma2(double matv[][], double mv[]) {
        int sigma_row = matv.length;
        int sigma_col = matv[0].length;
        System.out.println("Computing varience of variables of matrix: "+ sigma_row +" x "+sigma_col);
        double sigma2[] = new double[sigma_col];
        double temp[] = new double[sigma_col];
        for (int j = 0; j < sigma_col; j++) {
            temp[j] = 0.0;
        }//initilization of temp to zero
        for (int j = 0; j < sigma_col; j++) {//j columns
            for (int i = 0; i < sigma_row; i++) {//i rows
                //System.out.print(" "+mat[j][i]); 
                temp[j] = temp[j] + (matv[i][j] - mv[j]) * (matv[i][j] - mv[j]);
            }
            temp[j] = temp[j] / ((double) sigma_row);//for proper use of sigma2 do not use -1 
            //System.out.println(" >sigma2"+i+": "+temp[i]);       
        }
        //copy tem to sigma2
        System.arraycopy(temp, 0, sigma2, 0, sigma_col); //System.out.println(" "+sigma2[i]);

        return sigma2;
    }

    /*Computing multivariate gaussian*/
    public double[] multivarate_gaussian(double matg[][], double mg[], double vg[]) {
        //p = (2 * pi) ^ (- k / 2) * det(Sigma2) ^ (-0.5) * exp(-0.5 * sum(bsxfun(@times, X * pinv(Sigma2), X), 2))
        int i, j;
        int mvg_row = matg.length;
        int mvg_col = matg[0].length;
        System.out.println("Computing multivariate gaussian of corossvalidation matrix: "+ mvg_row +" x "+mvg_col);
        System.out.println("With the inputs of mean [1 x "+ mg.length +"] and varience [1 x "+ vg.length +"] of training data");

        double[][] x_mean = x_minus_mean(matg, mg);

        double[][] covar = sigmacovar(vg);
        /*calculating determinants of covarience matrix*/
        System.out.println("Computing determinants of covarience matrix: "+covar.length+" x "+covar[0].length);
        double detsigma2 = det_sigma(covar, covar[0].length);//matic and its column is input for comuting determentant
        //System.out.println("det :"+detsigma2);

        double[][] matInv = mat_Inverse(covar);
        //System.out.println("Inverse of Covarience matrix is");
        //display(ccol,ccol,matInv);

        /*multiplying matrix X-mu with Inverse of covarience matrix*/
        double[][] mul_res = Mat_Mul(x_mean, matInv);
        //System.out.println("cross set matric  multiplication");
        //display(crow,col,mul_res);

        /*multiplying matrix X-mu with earlier result by element*/
        double[][] mul_res_elt = mat_Mul_elt(mul_res, x_mean);
        //System.out.println("next  multiplication");
        //display(crow,col,mul_res_elt);

        double pvalmvg[] = new double[mvg_row];
        pvalmvg = sumrow_mat(mul_res_elt);

 
        for (i = 0; i < mvg_row; i++) {
            pvalmvg[i] = Math.exp(-0.5 * pvalmvg[i]);
            //System.out.println(" "+pvalmvg[i]); 
        }

        //System.out.println(" :"+Math.pow(detsigma2,-0.5));
        for (i = 0; i < mvg_row; i++) {
            pvalmvg[i] = Math.pow(detsigma2, -0.5) * pvalmvg[i];
            //System.out.println(" "+pvalmvg[i]); 
        }

        double twoPI = (double) 2.0 * 3.1416;
        double colbyTwo = (double) (-mvg_col / 2.0);
        //System.out.println(" :"+Math.pow(twoPI,colbyTwo));

        for (i = 0; i < mvg_row; i++) {
            pvalmvg[i] = Math.pow(twoPI, colbyTwo) * pvalmvg[i];
            //System.out.println(" "+pvalmvg[i]); 
        }
        return pvalmvg;
    }

    /*Computing covarience matrix*/
    public double[][] sigmacovar(double varmg[]) {
        int cov_col = varmg.length;
        System.out.println("Computing covarience matrix ["+cov_col +" x "+cov_col+"] of the vaience [1 x "+cov_col+"]of training data");
        double covarmg[][] = new double[cov_col][cov_col];

        for (int i = 0; i < cov_col; i++) {//i col
            for (int j = 0; j < cov_col; j++) {//j col
                if (i == j) {
                    covarmg[i][j] = varmg[i];
                } else {
                    covarmg[i][j] = 0.0;
                }
            }
        }
        return covarmg;
    }

    /*Coumuting x - mean*/
    public double[][] x_minus_mean(double matxm[][], double mean[]) {
        int xm_row = matxm.length;
        int xm_col = matxm[0].length;
        System.out.println("Subtracting mean [1 x "+mean.length+"] from crossvalidation matrix: "+xm_row+" x "+xm_col); 
        double x_m[][] = new double[xm_row][xm_col];

        for (int i = 0; i < xm_row; i++) {//i rows
            for (int j = 0; j < xm_col; j++) {// j columns
                x_m[i][j] = matxm[i][j] - mean[j];
                //System.out.print(" "+x_m[i][j]); 
            }
            //System.out.println(); 
        }
        return x_m;
    }

    /* find determinant of a square matrix */
    public double det_sigma(double A[][], int N) {
        //double det = 0.0;
        double det;

        if (N == 1) {
            det = A[0][0];
        } else if (N == 2) {
            det = A[0][0] * A[1][1] - A[1][0] * A[0][1];
        } else {
            det = 0;

            for (int j1 = 0; j1 < N; j1++) {
                m = new double[N - 1][];

                for (int k = 0; k < (N - 1); k++) {
                    m[k] = new double[N - 1];
                }
                for (int i = 1; i < N; i++) {
                    int j2 = 0;
                    for (int j = 0; j < N; j++) {
                        if (j == j1) {
                            continue;
                        }

                        m[i - 1][j2] = A[i][j];
                        j2++;
                    }
                }
                det += Math.pow(-1.0, 1.0 + j1 + 1.0) * A[0][j1] * det_sigma(m, N - 1);
            }
        }
        return det;
    }


    /* This function find inverse of matrix */
    double[][] mat_Inverse(double matin[][]) {
        boolean singular = false;
        int inv_row = matin.length;
        int inv_col = matin[0].length;
        System.out.println("Computing inverse of covariance matrix: "+inv_row+" x "+ inv_col);

        double[][] mat_inv = new double[inv_row][inv_col];
        for (int i = 0; i < inv_row; i++) {
            for (int j = 0; j < inv_col; j++) {
                mat_inv[i][j] = 0;
            }
            mat_inv[i][i] = 1;
        }

        for (int r = 0; (r < inv_row) && !singular; r++) {
            if ((int) matin[r][r] != 0) /* Diagonal element is not zero */ {
                for (int c = 0; c < inv_col; c++) {
                    if (c == r) {
                        /* Make all the elements above and below the current principal
                         diagonal element zero */
                        double ratio = matin[r][r];
                        for (int i = 0; i < inv_col; i++) {
                            matin[r][i] /= ratio;
                            mat_inv[r][i] /= ratio;
                        }
                    } else {
                        double ratio = matin[c][r] / matin[r][r];
                        for (int i = 0; i < inv_col; i++) {
                            matin[c][i] -= ratio * matin[r][i];
                            mat_inv[c][i] -= ratio * mat_inv[r][i];
                        }
                    }
                }
            } else {
                /* If principal diagonal element is zero */
                singular = true;
                for (int c = (r + 1); (c < inv_col) && singular; ++c) {
                    if ((int) matin[c][r] != 0) {
                        singular = false;
                        /* Find non zero elements in the same column */
                        swap(r, c, inv_col, matin, mat_inv);
                        --r;
                    }
                }
            }
        }
        return mat_inv;
    }


    /* This method is a part of Inverse function */
    void swap(int row1, int row2, int col, double mats[][], double mats1[][]) {
        for (int i = 0; i < col; i++) {
            double temp = mats[row1][i];
            mats[row1][i] = mats[row2][i];
            mats[row2][i] = temp;

            temp = mats1[row1][i];
            mats1[row1][i] = mats1[row2][i];
            mats1[row2][i] = temp;
        }
    }

    /* This method find the multiplication of two Matrix */
    public double[][] Mat_Mul(double mat1[][], double mat2[][]) {
        int row1 = mat1.length;//row of mat 1
        int col1 = mat1[0].length;//column of mat 1
        int row2 = mat2.length; //row of mat 2
        int col2 = mat2[0].length;//col of mat 2

        System.out.println("Multiplying matrix X-mu ["+row1+" x "+col1+"] with Inverse of covarience matrix ["+row2+" x "+col2+"]");
        System.out.println("Resultant matrix is: ["+row1+" x "+col2+"]");
        //if column of mat 1 is equal to row of mat 2 multiplication possible else not 
        //and resultent matrix will be of size row of mat 1 and col of mat 2
        double mat_mul_res[][] = new double[row1][col2];

        if (col1 == row2) {
            for (int i = 0; i < row1; i++) {
                for (int j = 0; j < col2; j++) {
                    mat_mul_res[i][j] = 0;
                    for (int k = 0; k < col1; k++) {
                        mat_mul_res[i][j] += mat1[i][k] * mat2[k][j];
                    }
                }
            }
        } else {
            System.out.printf("\n Multiplication is not possible");
        }
        return mat_mul_res;
    }

    /* This method find the multiplication of two Matrix by element wise*/
    public double[][] mat_Mul_elt(double mat1[][], double mat2[][]) {
        int row1 = mat1.length;//row of mat 1
        int col1 = mat1[0].length;//column of mat 1
        int row2 = mat2.length; //row of mat 2
        int col2 = mat2[0].length;//col of mat 2
        System.out.println("Element-wise multiplication of matrix X-mu ["+row1+" x "+col1+"] with x-mean matrix ["+row2+" x "+col2+"]");
        System.out.println("Resultant matrix is: ["+row1+" x "+col1+"]");
        
        double mat_res_elt1[][] = new double[row1][col1];

        if (row1 == row2 && col1 == col2) {
            for (int i = 0; i < row1; i++) {
                for (int j = 0; j < col1; j++) {
                    mat_res_elt1[i][j] = mat1[i][j] * mat2[i][j];
                }
            }
        } else {
            System.out.printf("\n Elements Multiplication is not possible");
        }

        return mat_res_elt1;
    }
    /*computing summation of rows of an matrix*/

    public double[] sumrow_mat(double mar_res1[][]) {
        int sum_row = mar_res1.length;
        int sum_col = mar_res1[0].length;
        double mat_res2[] = new double[sum_row];

        for (int i = 0; i < sum_row; i++) {
            for (int j = 0; j < sum_col; j++) {
                mat_res2[i] += mar_res1[i][j];
            }
        }
        //for(i =0; i<row; i++)
        // System.out.println(" "+mat_res2[i]);
        return mat_res2;
    }

    void display(int row, int col, double mat1[][]) {
        int i = 0, j = 0;
        System.out.println();
        /* Output of inverse Matrix */
        for (i = 0; i < row; i++) {
            for (j = 0; j < col; j++) {
                System.out.printf(" %.3f", mat1[i][j]);
            }
            System.out.println();
        }
    }

    double select_threshold(int yval[], double pval[]) {
        int crow = yval.length;        
        System.out.println("Finding Epsilon");

        double bst_ep = 0.0;

        double bstF1 = 0.0;

        double F1 = 0.0;

        double epmx = max(pval);
        double epmn = min(pval);

        System.out.println("Max pval:" + max(pval));
        System.out.println("Min pval:" + min(pval));

        double stepsize = (epmx - epmn) / 1000.0;

        double cr_ep = 0.0;

        for (cr_ep = epmn; cr_ep <= epmx; cr_ep = cr_ep + stepsize) {
            int cvprediction[] = new int[crow];

            cvprediction = cv_prediction(pval, cr_ep);
            //for(int i=0;i<crow;i++){System.out.println(yval[i]+" : "+ cvprediction[i]);}

            int tp = 0, fp = 0, fn = 0;

            tp = count_tp(cvprediction, yval);//System.out.println("tp:"+tp);
            fp = count_fp(cvprediction, yval);//System.out.println("fp:"+fp);
            fn = count_fn(cvprediction, yval);//System.out.println("fn:"+fn);

            if (tp == 0) {
                tp = tp + 1;//making sure that there is atleast one true positive 
            }

            double prec = (double) tp / ((double) (tp + fp));//System.out.println("prec:"+prec);
            double recl = (double) tp / ((double) (tp + fn));//System.out.println("recl:"+recl);

            F1 = (double) (2 * prec * recl) / ((double) (prec + recl));

            //System.out.println("F1    :"+F1);
            System.out.println("Cur_ep:" + cr_ep);

            if (F1 > bstF1) {
                bstF1 = F1;
                bst_ep = cr_ep;
            }
        }

        System.out.println("Best F1 Score :" + bstF1);
        return bst_ep;
    }

    /*computing true positive*/
    int count_tp(int predc[], int yval[]) {
        int crow = yval.length;
        int count = 0;

        for (int i = 0; i < crow; i++) {
            if ((predc[i] == 1) && (yval[i] == 1)) {
                count++;
            }
        }

        return count;
    }

    /*computing false positive*/
    int count_fp(int predc[], int yval[]) {
        int crow = yval.length;
        int count = 0;
        for (int i = 0; i < crow; i++) {
            if ((predc[i] == 1) && (yval[i] == 0)) {
                count++;
            }
        }
        return count;
    }

    /*computing false negetive*/
    int count_fn(int predc[], int yval[]) {
        int crow = yval.length;
        int count = 0;
        for (int i = 0; i < crow; i++) {
            if ((predc[i] == 0) && (yval[i] == 1)) {
                count++;
            }
        }
        return count;
    }

    int[] cv_prediction(double cvpval[], double ep) {
        int crow = cvpval.length;
        int val[] = new int[crow];
        for (int i = 0; i < crow; i++) {
            if (cvpval[i] < ep) {
                val[i] = 1;
            } else {
                val[i] = 0;
            }
        }
        return val;
    }

    double max(double pmx[]) {
        int crow = pmx.length;
        double temp = 0.0, max = 0.0;

        max = pmx[0];
        for (int i = 1; i < crow; i++) {
            if (pmx[i] > max) {
                max = pmx[i];
            }
        }
        return max;
    }

    double min(double pmn[]) {
        int crow = pmn.length;
        double temp = 0.0, min = 0.0;
        min = pmn[0];
        for (int i = 1; i < crow; i++) {
            if (pmn[i] < min) {
                min = pmn[i];
            }
        }
        return min;
    }

    public static void main(String[] args) {
        //System.out.println("Multivariate Gaussian Calculation");

        AnomalyDetection ad = new AnomalyDetection();
        ad.start();
    }

    private void readData() {
        String fileName = "";

        //read training data
        fileName = "Xtrain.csv";
        System.out.print("Reading training set");
        mat = readDataFromFile(fileName);
        int row = mat.length;
        int col = mat[0].length;
        System.out.println(" compleated.");

        //read crossvalidation data
        fileName = "Xcross.csv";
        System.out.print("Reading crossvalidation set");
        double[][] mattemp = readDataFromFile(fileName);
        int crow = mattemp.length;
        matc = new double[crow][col];//defineing crossvalidation materix
        yval = new int[crow];//defining the corss validation output column
        for (int i = 0; i < crow; i++) {
            int j = 0;
            for (; j < col; j++) {
                matc[i][j] = mattemp[i][j];
            }
            yval[i] = (int) mattemp[i][j];//reading output column
        }
        System.out.println(" compleated.");
        //read crossvalidation data
        fileName = "Xtest.csv";
        System.out.print("Reading test set");
        mattemp = readDataFromFile(fileName);
        int trow = mattemp.length;
        matt = new double[trow][col];//defining text matrix
        ytest = new int[trow];
        for (int i = 0; i < trow; i++) {
            int j = 0;
            for (; j < col; j++) {
                matt[i][j] = mattemp[i][j];
            }
            ytest[i] = (int) mattemp[i][j];//reading output column
        }
        System.out.println(" compleated.");
    }

    private double[][] readDataFromFile(String fileName) {
        int rowlength = 0;
        int collength = 0;
        double[][] data = null;
        String absolutePath = filePath + fileName;
        try {
            FileReader fin = new FileReader(absolutePath);//readt output Train to make ensemble
            BufferedReader br = new BufferedReader(fin);
            String line;
            String[] tokens;
            rowlength = 0;
            if ((line = br.readLine()) != null) {
                tokens = line.split(",");
                collength = tokens.length;
            }
            while ((line = br.readLine()) != null) {
                rowlength++;
            }
            //System.out.println("The file has " + rowlength + " samples");
            //System.out.println("Each sample has a leangth " + collength);

            data = new double[rowlength][collength];

            br.close();
            fin.close();

            FileReader fin1 = new FileReader(absolutePath);//readt output Train to make ensemble
            BufferedReader br1 = new BufferedReader(fin1);

            for (int i = 0; i < rowlength; i++) {
                line = br1.readLine();
                tokens = line.split(",");
                for (int j = 0; j < collength; j++) {
                    data[i][j] = Double.parseDouble(tokens[j]);
                }
            }
        } catch (IOException | NumberFormatException e) {
            System.out.println("Errot in data reading" + e);
        }
        return data;
    }
}
